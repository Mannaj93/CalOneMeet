export type TimeSlot = {
  hour: number;
  minute: number;
};

export type DaySchedule = {
  [key: string]: boolean;
};

export type WeeklySchedule = {
  [day: string]: DaySchedule;
};

export type Availability = {
  userId: string;
  name: string;
  schedule: WeeklySchedule;
};