export const DAYS = ['Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday', 'Sunday'];
export const START_HOUR = 8;
export const END_HOUR = 23;
export const HOURS = Array.from(
  { length: END_HOUR - START_HOUR + 1 }, 
  (_, i) => i + START_HOUR
);