import React from 'react';
import { WeeklySchedule } from '../types/schedule';
import { DAYS, HOURS } from '../utils/constants';

type TimeGridProps = {
  schedule: WeeklySchedule;
  onCellClick: (day: string, time: string) => void;
  isEditable?: boolean;
};

export function TimeGrid({ schedule, onCellClick, isEditable = true }: TimeGridProps) {
  return (
    <div className="overflow-x-auto">
      <div className="min-w-[800px]">
        <div className="grid grid-cols-[100px_repeat(7,1fr)]">
          <div className="font-semibold">Time</div>
          {DAYS.map((day) => (
            <div key={day} className="font-semibold text-center py-2">
              {day}
            </div>
          ))}

          {HOURS.map((hour) => (
            <React.Fragment key={hour}>
              <div className="border-t py-2 text-sm">
                {hour.toString().padStart(2, '0')}:00
              </div>
              {DAYS.map((day) => {
                const timeKey = `${hour}:00`;
                const isSelected = schedule[day]?.[timeKey];
                
                return (
                  <div
                    key={`${day}-${hour}`}
                    onClick={() => isEditable && onCellClick(day, timeKey)}
                    className={`border-t border-l cursor-pointer transition-colors ${
                      isSelected
                        ? 'bg-blue-500 hover:bg-blue-600'
                        : 'hover:bg-gray-100'
                    }`}
                  />
                );
              })}
            </React.Fragment>
          ))}
        </div>
      </div>
    </div>
  );
}