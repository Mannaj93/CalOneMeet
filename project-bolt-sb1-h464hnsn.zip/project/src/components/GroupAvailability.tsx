import React from 'react';
import { Availability } from '../types/schedule';
import { TimeGrid } from './TimeGrid';

type GroupAvailabilityProps = {
  availabilities: Availability[];
};

export function GroupAvailability({ availabilities }: GroupAvailabilityProps) {
  const combinedSchedule = availabilities.reduce((acc, curr) => {
    const schedule = { ...acc };
    Object.entries(curr.schedule).forEach(([day, times]) => {
      if (!schedule[day]) schedule[day] = {};
      Object.entries(times).forEach(([time, available]) => {
        if (!schedule[day][time]) schedule[day][time] = true;
        schedule[day][time] = schedule[day][time] && available;
      });
    });
    return schedule;
  }, {} as Record<string, Record<string, boolean>>);

  return (
    <div className="mt-8">
      <h2 className="text-xl font-bold mb-4">Group Availability</h2>
      <TimeGrid
        schedule={combinedSchedule}
        onCellClick={() => {}}
        isEditable={false}
      />
      <div className="mt-4">
        <h3 className="font-semibold mb-2">Participants:</h3>
        <ul className="space-y-1">
          {availabilities.map((availability) => (
            <li key={availability.userId}>{availability.name}</li>
          ))}
        </ul>
      </div>
    </div>
  );
}