import React, { useState } from 'react';
import { Share2 } from 'lucide-react';
import { TimeGrid } from './components/TimeGrid';
import { GroupAvailability } from './components/GroupAvailability';
import type { WeeklySchedule, Availability } from './types/schedule';

function App() {
  const [schedule, setSchedule] = useState<WeeklySchedule>({});
  const [name, setName] = useState('');
  const [isSubmitted, setIsSubmitted] = useState(false);

  // Simulated group data - in a real app this would come from a database
  const mockAvailabilities: Availability[] = [
    {
      userId: '1',
      name: 'You',
      schedule: schedule
    }
  ];

  const handleCellClick = (day: string, time: string) => {
    setSchedule((prev) => ({
      ...prev,
      [day]: {
        ...prev[day],
        [time]: !prev[day]?.[time]
      }
    }));
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!name.trim()) return;
    setIsSubmitted(true);
  };

  return (
    <div className="min-h-screen bg-gray-50 py-8 px-4">
      <div className="max-w-6xl mx-auto">
        <div className="bg-white rounded-lg shadow-lg p-6">
          <div className="flex items-center justify-between mb-6">
            <h1 className="text-2xl font-bold text-gray-900">WeeklyMeet</h1>
            <button
              className="flex items-center gap-2 px-4 py-2 bg-blue-500 text-white rounded-md hover:bg-blue-600 transition-colors"
              onClick={() => {
                // In a real app, this would generate a unique URL
                alert('Share link copied to clipboard!');
              }}
            >
              <Share2 size={20} />
              Share
            </button>
          </div>

          <div className="bg-blue-50 border-l-4 border-blue-500 p-4 mb-6">
            <p className="text-blue-700">
              Select your available time slots for the week. Share the link with others to find the best time to meet!
            </p>
          </div>

          {!isSubmitted ? (
            <form onSubmit={handleSubmit} className="space-y-6">
              <div>
                <label htmlFor="name" className="block text-sm font-medium text-gray-700">
                  Your Name
                </label>
                <input
                  type="text"
                  id="name"
                  value={name}
                  onChange={(e) => setName(e.target.value)}
                  className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-blue-500 focus:ring-blue-500"
                  placeholder="Enter your name"
                  required
                />
              </div>

              <div>
                <h2 className="text-xl font-bold mb-4">Your Availability</h2>
                <TimeGrid schedule={schedule} onCellClick={handleCellClick} />
              </div>

              <button
                type="submit"
                className="w-full px-4 py-2 bg-blue-500 text-white rounded-md hover:bg-blue-600 transition-colors"
              >
                Submit Availability
              </button>
            </form>
          ) : (
            <GroupAvailability availabilities={mockAvailabilities} />
          )}
        </div>
      </div>
    </div>
  );
}

export default App;